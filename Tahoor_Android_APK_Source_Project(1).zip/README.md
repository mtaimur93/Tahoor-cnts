# Tahoor App Android source

This Android app opens the Tahoor Construction & Tech Solutions website:
https://tahoorcnts.netlify.app/

## Build APK with GitHub Actions
1. Upload the contents of this project folder to the root of your GitHub repository.
2. Open the repository's Actions tab.
3. Run or wait for the workflow named "Build Tahoor Android APK".
4. Download the `Tahoor-App-debug-apk` artifact and extract `app-debug.apk`.

Note: This is a WebView wrapper. Website account login, OTP authentication, and a real admin backend must be implemented separately on the website/server; this project does not create those backend features.
